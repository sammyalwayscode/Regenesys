import React from "react";

const SignUp = () => {
  return (
    <div>
      <h1>This is the Sign Up Page</h1>
    </div>
  );
};

export default SignUp;
