import React from "react";

const BookDetail = () => {
  return <div>BookDetail</div>;
};

export default BookDetail;
